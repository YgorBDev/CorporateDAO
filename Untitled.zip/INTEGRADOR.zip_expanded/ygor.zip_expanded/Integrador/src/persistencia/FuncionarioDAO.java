package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Funcionario;

public class FuncionarioDAO {
    private Connection bd;

    public FuncionarioDAO() {
        this.bd = BancosDeDados.getBd();
    }

    public void create(Funcionario f) throws SQLException {
        String query = "INSERT INTO funcionario VALUES (null, null,?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement st = this.bd.prepareStatement(query)) {
            st.setString(1, f.getNomeFuncionario());
            st.setString(2, f.getCpf());
            st.setDouble(3, f.getSalario());
            st.setDouble(4, f.getValorImposto());
            st.setString(5, f.getCargo());
            st.setString(6, f.getCelular());
            st.setString(7, f.getDataNasc()); 
            st.setString(8, f.getDataAdmissao()); 
            
            
            st.executeUpdate();
        }
    }

    public ArrayList<Funcionario> getAll() throws SQLException {
        ArrayList<Funcionario> lista = new ArrayList<>();
        String query = "SELECT * FROM funcionario"; 
        try (PreparedStatement st = this.bd.prepareStatement(query);
             ResultSet res = st.executeQuery()) {
            while (res.next()) {             	
            	 	String nomeFuncionario = res.getString("nomeFuncionario");
            	 	String cpf = res.getString("cpf");
            	 	Double salario = res.getDouble("salario");
            	 	Double valorImposto = res.getDouble("valorImposto");
            	 	String cargo = res.getString("cargo");
            	 	String celular = res.getString("celular");
            	 	String dataNasc = res.getString("dataNasc");
            	 	String dataAdmissao = res.getString("dataAdmissao");
                	Funcionario f = new Funcionario( nomeFuncionario,  cpf, salario, valorImposto, cargo,  celular,  dataNasc,  dataAdmissao);
                	lista.add(f);
            }
        }
        return lista;
    }

    public void update(Funcionario f) throws SQLException {
        String query = "UPDATE funcionario SET nomeFuncionario = ?, cpf = ?, valorImposto = ?, dataNasc = ?, cargo = ?, salario = ?, celular = ?, dataAdmissao = ? WHERE cpf = ?";
        try (PreparedStatement st = this.bd.prepareStatement(query)) {
            st.setString(1, f.getNomeFuncionario());
            st.setString(2, f.getCpf());
            st.setDouble(6, f.getSalario());
            st.setDouble(3, f.getValorImposto());
            st.setString(5, f.getCargo());
            st.setString(7, f.getCelular());
            st.setString(4, f.getDataNasc());
            st.setString(8, f.getDataAdmissao());
            st.setString(9, f.getCpf());
            st.executeUpdate();
        }
    }

    public void delete(Funcionario f) throws SQLException {
        String query = "DELETE FROM funcionario WHERE cpf = ?";
        try (PreparedStatement st = this.bd.prepareStatement(query)) {
            st.setString(1, f.getCpf());
            st.executeUpdate();
        }
    }

    public ArrayList<Funcionario> findByNomeLike(String s) throws SQLException {
        ArrayList<Funcionario> lista = new ArrayList<>();
        String query = "SELECT * FROM funcionario WHERE nomeFuncionario LIKE ?";
        try (PreparedStatement st = this.bd.prepareStatement(query)) {
            st.setString(1, "%" + s + "%");
            try (ResultSet res = st.executeQuery()) {
                while (res.next()) {
                    	 	String nomeFuncionario = res.getString("nomeFuncionario");
                    	 	String cpf = res.getString("cpf");
                    	 	Double valorImposto = res.getDouble("valorImposto");
                    	 	String dataNasc = res.getString("dataNasc");
                    	 	String cargo = res.getString("cargo");
                    	 	Double salario = res.getDouble("salario");
                    	 	String celular = res.getString("celular");
                    	 	String dataAdmissao = res.getString("dataAdmissao");
                        	Funcionario f = new Funcionario( nomeFuncionario,  cpf,  valorImposto,  salario,  cargo,  dataNasc,  celular,  dataAdmissao);
                    lista.add(f);
                }
            }
        }
        return lista;
    }
}
