package apresentacao;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.Scanner;

import model.Empresa;
import model.Funcionario;
import model.Imposto;
import persistencia.EmpresaDAO;
import persistencia.FuncionarioDAO;
import persistencia.ImpostoDAO;
 
public class Main {
	public static void main(String[] args) {  

		try {
			Scanner teclado = new Scanner(System.in);

			while (true) {
				System.out.println("\n== Sistema Empresarial ==");
				System.out.println("01) Cadastrar uma empresa");
				System.out.println("02) Mostrar as empresas cadastradas");
				System.out.println("03) Buscar empresa");
				System.out.println("04) Editar empresa");
				System.out.println("");
				System.out.println("05) Cadastrar um funcionario");
				System.out.println("06) Mostrar os funcionario cadastradas");
				System.out.println("07) Buscar funcionario");	
				System.out.println("08) Editar funcionario");
				System.out.println("");
				System.out.println("09) Declarar imposto empresa");
				System.out.println("10) Mostar declaraçoes imposto");
				System.out.println("11) Buscar declaraçoes");	
				System.out.println("12) Editar declaraçoes");				
				System.out.println("");
				System.out.println("13) Excluir empresa");
				System.out.println("14) Excluir funcionario");
				System.out.println("15) Excluir declaraçoes");
				System.out.println("16) Encerrar");
				System.out.println("");
				System.out.print("Escolha uma opção: ");
				int opcao = teclado.nextInt();
				teclado.nextLine();

				if (opcao == 1) { // Cadastrar uma empresa
					try {
						  System.out.print("\nDigite o nome da empresa: ");
	                        String nomeEmpresa = teclado.nextLine();
	                        System.out.print("Digite o CNPJ da empresa: ");
	                        String cnpj = teclado.nextLine();
	                        System.out.print("Digite o lugar: ");
	                        String lugar = teclado.nextLine();
	                        System.out.print("Digite a data de criação (YYYY-MM-DD): ");
	                        String dataCriacao = teclado.nextLine();
	                        System.out.print("Digite a quantidade de funcionários: ");
	                        Double qtdeFuncionario = teclado.nextDouble();
	                        System.out.print("Digite o lucro bruto: ");
	                        Double lucroBruto = teclado.nextDouble();
	                        System.out.print("Digite o lucro liquido: ");
	                        Double lucroLiquido = teclado.nextDouble();
	      
	                        Empresa e = new Empresa(nomeEmpresa, cnpj, lugar, dataCriacao, qtdeFuncionario, lucroBruto, lucroLiquido); 
	                	    	
	                        	EmpresaDAO ed = new EmpresaDAO();
	    						ed.create(e);
	    					} catch (SQLIntegrityConstraintViolationException e) {
	    				
	    						System.out.println("\n*** Esse CNPJ já foi cadastrado!");
	    						continue;
	    					}
	    					System.out.println("\nEmpresa cadastrada com sucesso!");
	    				}
				else if (opcao == 2) { // Mostrar as empresas cadastradas
					EmpresaDAO ed = new EmpresaDAO();
					ArrayList<Empresa> lista = ed.getAll();
					if (lista.size() == 0) {
						System.out.println("\nO cadastro está vazio.");
					} else {
						System.out.println("\nEmpresa cadastradas:");
						for (Empresa e: lista) {
							System.out.println(e);
						}
					}
				}
				else if (opcao==3) { // Buscar empresa       
					System.out.print("Digite uma parte do nome da empresa: ");
					String parte = teclado.nextLine();
					EmpresaDAO ed = new EmpresaDAO();
					ArrayList<Empresa> lista = ed.findByNomeLike(parte);
					if (lista.size() == 0) {
						System.out.println("\nNenhum resultado.");
					} else {
						System.out.println("\nResultado da pesquisa:");
						for (Empresa e: lista) {
							System.out.println(e);
						}
					}
				}	
				
				else if (opcao==4) { // Editar empresa
					EmpresaDAO ed = new EmpresaDAO();
					ArrayList<Empresa> lista = ed.getAll();
					if (lista.size() == 0) {
						System.out.println("\nO cadastro está vazio.");
					} else {
						int i = 0;
						System.out.println("\nEmpresas cadastradas:");
						for (Empresa e: lista) {
							System.out.printf("[%d] %s\n", i++, e);
						}
						System.out.print("Qual Empresa deseja atualizar? ");
						int j = teclado.nextInt();
						teclado.nextLine();
						System.out.print("Qual o novo nome? ");
						String nomeEmpresa = teclado.nextLine();
						Empresa e = lista.get(j);
						e.setNomeEmpresa(nomeEmpresa);
						ed.update(e);
						System.out.println("\nCadastro atualizado com sucesso!");
					}
				}
				else if (opcao==5) { // Cadastrar um funcionario 
 
					try {
							System.out.print("\nDigite o id da empresa: ");
							Double idEmpresa = teclado.nextDouble();
							System.out.print("\nDigite o nome do funcionario: ");
	                        String nome = teclado.next();
	                        System.out.print("Digite o CPF do funcionario: ");
	                        String cpf = teclado.next();
	                        System.out.print("Digite a data de nascimento (YYYY-MM-DD): ");
	                        String dataNasc = teclado.next();
	                        System.out.print("Digite o cargo do funcionário: ");
	                        String cargo = teclado.next();
	                        System.out.print("Digite o salario: ");
	                        Double salario = teclado.nextDouble();
	                        System.out.print("Digite o celular: ");
	                        String celular = teclado.next();
	    	                System.out.print("Digite a data de admissao (YYYY-MM-DD): ");
	    	                String dataAdmissao = teclado.next();
	    	                
	                    	Funcionario f = new Funcionario(idEmpresa,nome, cpf,  salario,  cargo,  dataNasc,  celular,  dataAdmissao);
	                	    	
	                    	FuncionarioDAO fd = new FuncionarioDAO();
	                    		fd.create(f);
	    					} catch (SQLIntegrityConstraintViolationException e) {
	    				
	    						System.out.println("\n*** Esse CPF já foi cadastrado!");
	    						continue;
	    					}
	    					System.out.println("\nFuncionario cadastrado com sucesso!");
	    				}
				else if (opcao==6) { // Mostrar os funcionarios cadastrados
					FuncionarioDAO fd = new FuncionarioDAO();
					ArrayList<Funcionario> lista = fd.getAll();
					if (lista.size() == 0) {
						System.out.println("\nO cadastro está vazio.");
					} else {
						System.out.println("\nFuncionarios cadastrados:");
						for (Funcionario f: lista) {
							System.out.println(f);
						}
					}
				}	
				else if (opcao==7) { // Buscar funcionario
					System.out.print("Digite uma parte do nome do funcionario: ");
					String parte = teclado.nextLine();
					FuncionarioDAO fd = new FuncionarioDAO();
					ArrayList<Funcionario> lista = fd.findByNomeLike(parte);
					if (lista.size() == 0) {
						System.out.println("\nNenhum resultado.");
					} else {
						System.out.println("\nResultado da pesquisa:");
						for (Funcionario f: lista) {
							System.out.println(f);
						}
					}
				}				
				else if (opcao==8) {  // Editar funcionario
					FuncionarioDAO fd = new FuncionarioDAO();
					ArrayList<Funcionario> lista = fd.getAll();
					if (lista.size() == 0) {
						System.out.println("\nO cadastro está vazio.");
					} else {
						int i = 0;
						System.out.println("\nFuncionarios cadastradas:");
						for (Funcionario f: lista) {
							System.out.printf("[%d] %s\n", i++, f);
						}
						System.out.print("Qual Funcionario deseja atualizar? ");
						int j = teclado.nextInt();
						teclado.nextLine();
						System.out.print("Qual o novo nome? ");
						String nome = teclado.nextLine();
						Funcionario f = lista.get(j);
						f.setNome(nome);
						fd.update(f);
						System.out.println("\nCadastro atualizado com sucesso!");
					}
				}
				else if (opcao==9) { // Declarar imposto empresa
					try {
						  System.out.print("\nDigite o id da empresa: ");
						  Double idEmpresa = teclado.nextDouble();
						  System.out.print("\nDigite o ano em que o imposto está a ser pago: ");
	                      int ano = teclado.nextInt();
	                      System.out.print("Digite o valor do imposto : ");
	                      Double valor = teclado.nextDouble();
	                      System.out.print("Digite a data de declaração do imposto: ");
	                      String dataDeclaracao = teclado.next();
                          Imposto i = new Imposto(idEmpresa, ano, valor, dataDeclaracao);
	                  	  ImpostoDAO id = new ImpostoDAO();
	                  	  id.create(i);
	                  		
	  					} catch (SQLIntegrityConstraintViolationException e) {
	 						System.out.println("\n*** Declaração já existe.");
	  						continue;
	  					}

	  					System.out.println("\nDeclaração cadastrado com sucesso!");

					} 
				else if (opcao==10) { // Mostar declaraçoes imposto
					ImpostoDAO id = new ImpostoDAO();
					ArrayList<Imposto> lista = id.getAll();
					if (lista.size() == 0) {
						System.out.println("\nO cadastro está vazio.");
					} else {
						System.out.println("\nImpostos cadastrados:");
						for (Imposto i: lista) {
							System.out.println(i);
						}
					}
				}	
				else if (opcao==11) { // Buscar declaraçoes
					System.out.print("Digite o id da empresa: ");
					Double parte = teclado.nextDouble();
					ImpostoDAO id = new ImpostoDAO();
					ArrayList<Imposto> lista = id.findByNomeLike(parte);
					if (lista.size() == 0) {
						System.out.println("\nNenhum resultado.");
					} else {
						System.out.println("\nResultado da pesquisa:");
						for (Imposto i: lista) {
							System.out.println(i);
						}
					}
				}	
				else if (opcao==12) { // Editar declaraçoes
					ImpostoDAO id = new ImpostoDAO();
					ArrayList<Imposto> lista = id.getAll();
					if (lista.size() == 0) {
						System.out.println("\nO cadastro está vazio.");
					} else {
						int l = 0;
						System.out.println("\nImpostos cadastradas:");
						for (Imposto i: lista) {
							System.out.printf("[%d] %s\n", l++, i);
						}
						System.out.print("Qual imposto deseja atualizar? ");
						int j = teclado.nextInt();
						teclado.nextLine();
						System.out.print("Qual o novo valor? ");
						Double valor = teclado.nextDouble();
						Imposto i = lista.get(j);
						i.setValor(valor);
						id.update(i);
						System.out.println("\nCadastro atualizado com sucesso!");
					}
				}
				else if (opcao==13) { // Excluir Empresas
					EmpresaDAO ed = new EmpresaDAO();
					ArrayList<Empresa> lista = ed.getAll();
					if (lista.size() == 0) {
						System.out.println("\nO cadastro está vazio.");
					} else {
						int i = 0;
						System.out.println("\nEmpresas cadastradas:");
						for (Empresa e: lista) {
							System.out.printf("[%d] %s\n", i++, e);
						}
						System.out.print("Qual Empresa deseja remover? ");
						int j = teclado.nextInt();
						teclado.nextLine();
						Empresa e = lista.get(j);
						ed.delete(e);
						System.out.println("\nCadastro atualizado com sucesso!");
					}
				}
				else if (opcao==14) { // Excluir Funcionarios
					FuncionarioDAO fd = new FuncionarioDAO();
					ArrayList<Funcionario> lista = fd.getAll();
					if (lista.size() == 0) {
						System.out.println("\nO cadastro está vazio.");
					} else {
						int i = 0;
						System.out.println("\nFuncionarios cadastradas:");
						for (Funcionario f: lista) {
							System.out.printf("[%d] %s\n", i++, f);
						}
						System.out.print("Qual Funcionario deseja remover? ");
						int j = teclado.nextInt();
						teclado.nextLine();
						Funcionario f = lista.get(j);
						fd.delete(f);
						System.out.println("\nCadastro atualizado com sucesso!");
					}
				}
				else if (opcao==15) { // Excluir declarações
					ImpostoDAO id = new ImpostoDAO();
					ArrayList<Imposto> lista = id.getAll();
					if (lista.size() == 0) {
						System.out.println("\nO cadastro está vazio.");
					} else {
						int l = 0;
						System.out.println("\nImpostos cadastradas:");
						for (Imposto i: lista) {
							System.out.printf("[%d] %s\n", l++, i);
						}
						System.out.print("Qual Imposto deseja remover? ");
						int j = teclado.nextInt();
						teclado.nextLine();
						Imposto f = lista.get(j);
						id.delete(f);
						System.out.println("\nCadastro atualizado com sucesso!");
					}
				}
				else if (opcao == 16) { // Encerrar codigo
					break;
				}
				else {
					System.out.println("Opção inválida!");
				}
			}
			teclado.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			System.out.println("\nTenha um bom dia!");
		}
	}

}