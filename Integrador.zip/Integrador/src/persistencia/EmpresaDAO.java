package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Empresa;

public class EmpresaDAO {
    private Connection bd;

    public EmpresaDAO() {
        this.bd = BancosDeDados.getBd();
    }

    public void create(Empresa e) throws SQLException {
        String query = "INSERT INTO empresa VALUES(null, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement st = this.bd.prepareStatement(query)) {
            st.setString(1, e.getNomeEmpresa());
            st.setString(2, e.getCnpj());
            st.setString(3, e.getLugar());
            st.setString(4, e.getDataCriacao());
            st.setDouble(5, e.getQtdeFuncionario());
            st.setDouble(6, e.getLucroBruto());
            st.setDouble(7, e.getLucroLiquido());
     
       
            st.executeUpdate();
        }
    }

    public ArrayList<Empresa> getAll() throws SQLException {
        ArrayList<Empresa> lista = new ArrayList<>();
        String query = "SELECT * FROM empresa"; 
        try (PreparedStatement st = this.bd.prepareStatement(query);
             ResultSet res = st.executeQuery()) {
            while (res.next()) {
                String nomeEmpresa = res.getString("nomeEmpresa");
                String cnpj = res.getString("cnpj");
                String lugar = res.getString("lugar");
                String dataCriacao = res.getString("dataCriacao");
                Double qtdeFuncionario = res.getDouble("qtdeFuncionario");
                Double lucroBruto = res.getDouble("lucroBruto");
                Double lucroLiquido = res.getDouble("lucroLiquido");
                Empresa e = new Empresa(nomeEmpresa, cnpj, lugar,dataCriacao, qtdeFuncionario,  lucroBruto, lucroLiquido);
                lista.add(e);
            }
        }
        return lista;
    }

    public void update(Empresa e) throws SQLException {
        String query = "UPDATE empresa SET nomeEmpresa = ?, lugar = ?, dataCriacao = ?, qtdeFuncionario = ?, lucroBruto = ?, lucroLiquido = ? WHERE cnpj = ?";
        try (PreparedStatement st = this.bd.prepareStatement(query)) {
            st.setString(1, e.getNomeEmpresa());
            st.setString(2, e.getLugar());
            st.setString(3, e.getDataCriacao());
            st.setDouble(4, e.getQtdeFuncionario());
            st.setDouble(5, e.getLucroBruto());
            st.setDouble(6, e.getLucroLiquido());
            st.setString(7, e.getCnpj());
            st.executeUpdate();
        }
    }

    public void delete(Empresa e) throws SQLException {
        String query = "DELETE FROM empresa WHERE cnpj = ?";
        try (PreparedStatement st = this.bd.prepareStatement(query)) {
            st.setString(1, e.getCnpj());
            st.executeUpdate();
        }
    }

    public ArrayList<Empresa> findByNomeLike(String s) throws SQLException {
        ArrayList<Empresa> lista = new ArrayList<>();
        String query = "SELECT * FROM empresa WHERE nomeEmpresa LIKE ?";
        try (PreparedStatement st = this.bd.prepareStatement(query)) {
            st.setString(1, "%" + s + "%");
            try (ResultSet res = st.executeQuery()) {
                while (res.next()) {
                    String nomeEmpresa = res.getString("nomeEmpresa");
                    String cnpj = res.getString("cnpj");
                    String lugar = res.getString("lugar");
                    String dataCriacao = res.getString("dataCriacao");
                    Double qtdeFuncionario = res.getDouble("qtdeFuncionario");
                    Double lucroBruto = res.getDouble("lucroBruto");
                    Double lucroLiquido = res.getDouble("lucroLiquido");
                    Empresa e = new Empresa(nomeEmpresa, cnpj, lugar, dataCriacao, qtdeFuncionario, lucroBruto, lucroLiquido);
                    lista.add(e);
                }
            }
        }
        return lista;
    }
}
