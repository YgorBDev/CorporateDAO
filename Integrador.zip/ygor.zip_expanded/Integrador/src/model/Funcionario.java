package model;

public class Funcionario {
	private Double idEmpresa;
    private String nomeFuncionario;
    private String cpf;
    private Double valorImposto;
    private String dataNasc;
    private String cargo;
    private Double salario;
    private String celular;
    private String dataAdmissao;


    

    public Funcionario( Double idEmpresa, String nomeFuncionario, String cpf, Double valorImposto, String dataNasc, String cargo, Double salario, String celular, String dataAdmissao) {
    	this.idEmpresa = idEmpresa;
        this.nomeFuncionario = nomeFuncionario;
        this.cpf = cpf;
        this.valorImposto = valorImposto;
        this.dataNasc = dataNasc;
        this.cargo = cargo;
        this.salario = salario;
        this.celular = celular;
        this.dataAdmissao = dataAdmissao;

    }

	public double getIdEmpresa() {
        return idEmpresa;
    }

    public void setIdEmpresa(Double idEmpresa) {
        this.idEmpresa = idEmpresa;
    }
    
	public String getNomeFuncionario() {
        return nomeFuncionario;
    }

    public void setNomeFuncionario(String nomeFuncionario) {
        this.nomeFuncionario = nomeFuncionario;
    }
    
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public double getValorImposto() {
        return valorImposto;
    }

    public void setValorImposto(Double valorImposto) {
        this.valorImposto = valorImposto;
    }

    public String getDataNasc() {
       return dataNasc;
    }
    
    public void setDataNasc(String dataNasc) {
        this.dataNasc = dataNasc;
    }
    
    public String getCargo() {
        return cargo;
    }
    
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    public double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getDataAdmissao() {
        return dataAdmissao;
    }
    
    public void setDataAdmissao(String dataAdmissao) {
        this.dataAdmissao = dataAdmissao;
    }
    
    public String toString() {
        return "Funcionario{" +
                "idEmpresa=" + idEmpresa +
                ", nomeFuncionario='" + nomeFuncionario + '\'' +
                ", cpf='" + cpf + '\'' +
                ", valorImposto=" + valorImposto +
                ", dataNasc=" + dataNasc +
                ", cargo='" + cargo + '\'' +
                ", salario=" + salario +
                ", celular='" + celular + '\'' +
                ", dataAdmissao=" + dataAdmissao +
                '}';
    }

}