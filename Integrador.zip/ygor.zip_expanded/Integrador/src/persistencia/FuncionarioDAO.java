package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Funcionario;

public class FuncionarioDAO {
    private Connection bd;

    public FuncionarioDAO() {
        this.bd = BancosDeDados.getBd();
    }

    public void create(Funcionario f) throws SQLException {
        String query = "INSERT INTO funcionario (id_empresa, nome_funcionario, cpf, valor_imposto, data_nasc, cargo, salario, celular, data_admissao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement st = this.bd.prepareStatement(query)) {
            st.setDouble(1, f.getIdEmpresa());
            st.setString(2, f.getNomeFuncionario());
            st.setString(3, f.getCpf());
            st.setDouble(4, f.getValorImposto());
            st.setString(5, f.getDataNasc()); 
            st.setString(6, f.getCargo());
            st.setDouble(7, f.getSalario());
            st.setString(8, f.getCelular());
            st.setString(9, f.getDataAdmissao()); 

            st.executeUpdate();
        }
    }

    public ArrayList<Funcionario> getAll() throws SQLException {
        ArrayList<Funcionario> lista = new ArrayList<>();
        String query = "SELECT * FROM funcionario"; 
        try (PreparedStatement st = this.bd.prepareStatement(query);
             ResultSet res = st.executeQuery()) {
            while (res.next()) {
                Funcionario f = new Funcionario(
                    res.getDouble("id_empresa"),
                    res.getString("nome_funcionario"),
                    res.getString("cpf"),
                    res.getDouble("valor_imposto"),
                    res.getDouble("data_nasc"),
                    res.getString("cargo"),
                    res.getDouble("salario"),
                    res.getString("celular"),
                    res.getDouble("data_admissao")
                );
                lista.add(f);
            }
        }
        return lista;
    }

    public void update(Funcionario f) throws SQLException {
        String query = "UPDATE funcionario SET nome_funcionario = ?, cpf = ?, valor_imposto = ?, data_nasc = ?, cargo = ?, salario = ?, celular = ?, data_admissao = ? WHERE cpf = ?";
        try (PreparedStatement st = this.bd.prepareStatement(query)) {
            st.setString(1, f.getNomeFuncionario());
            st.setString(2, f.getCpf());
            st.setDouble(3, f.getValorImposto());
            st.setDouble(4, f.getDataNasc());
            st.setString(5, f.getCargo());
            st.setDouble(6, f.getSalario());
            st.setString(7, f.getCelular());
            st.setDouble(8, f.getDataAdmissao());
            st.setString(9, f.getCpf());
            st.executeUpdate();
        }
    }

    public void delete(Funcionario f) throws SQLException {
        String query = "DELETE FROM funcionario WHERE cpf = ?";
        try (PreparedStatement st = this.bd.prepareStatement(query)) {
            st.setString(1, f.getCpf());
            st.executeUpdate();
        }
    }

    public ArrayList<Funcionario> findByNomeLike(String s) throws SQLException {
        ArrayList<Funcionario> lista = new ArrayList<>();
        String query = "SELECT * FROM funcionario WHERE nome_funcionario LIKE ?";
        try (PreparedStatement st = this.bd.prepareStatement(query)) {
            st.setString(1, "%" + s + "%");
            try (ResultSet res = st.executeQuery()) {
                while (res.next()) {
                    Funcionario f = new Funcionario(
                        res.getDouble("id_empresa"),
                        res.getString("nome_funcionario"),
                        res.getString("cpf"),
                        res.getDouble("valor_imposto"),
                        res.getDouble("data_nasc"),
                        res.getString("cargo"),
                        res.getDouble("salario"),
                        res.getString("celular"),
                        res.getDouble("data_admissao")
                    );
                    lista.add(f);
                }
            }
        }
        return lista;
    }
}
