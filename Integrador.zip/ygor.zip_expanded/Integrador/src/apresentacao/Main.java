package apresentacao;

import java.util.ArrayList;
import java.util.Scanner;
import model.Empresa;
import model.Funcionario;
import persistencia.EmpresaDAO;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

 
public class Main {
	public static void main(String[] args) {  

		try {
			Scanner teclado = new Scanner(System.in);

			while (true) {
				System.out.println("\n== Sistema Empresarial ==");
				System.out.println("1) Cadastrar uma empresa");
				System.out.println("2) Mostrar as empresas cadastradas");
				System.out.println("3) Buscar empresa");
				System.out.println("4) Cadastrar um funcionario");
				System.out.println("5) Mostrar os funcionario cadastradas");
				System.out.println("6) Buscar funcionario");	
				System.out.println("7) Declarar imposto empresa");
				System.out.println("8) Mostar declaraçoes imposto");
				System.out.println("9) Excluir funcionario");
				System.out.println("10) Excluir empresa");
				System.out.println("11) Encerrar");
				
				System.out.print("Escolha uma opção: ");
				int opcao = teclado.nextInt();
				teclado.nextLine();

				if (opcao == 1) {
					try {
						  System.out.print("\nDigite o nome da empresa: ");
	                        String nomeEmpresa = teclado.nextLine();
	                        System.out.print("Digite o CNPJ da empresa: ");
	                        String cnpj = teclado.nextLine();
	                        System.out.print("Digite o lugar: ");
	                        String lugar = teclado.nextLine();
	                        System.out.print("Digite a data de criação (YYYY-MM-DD): ");
	                        String dataCriacao = teclado.nextLine();
	                        System.out.print("Digite a quantidade de funcionários: ");
	                        Double qtdeFuncionario = teclado.nextDouble();
	                        System.out.print("Digite o lucro bruto: ");
	                        Double lucroBruto = teclado.nextDouble();
	                        System.out.print("Digite o lucro liquido: ");
	                        Double lucroLiquido = teclado.nextDouble();
	    	                System.out.print("Digite o imposto: ");
	                        Double imposto = teclado.nextDouble();
	                  
	                        
	                        Empresa e = new Empresa(nomeEmpresa, cnpj, lugar, dataCriacao, qtdeFuncionario, lucroBruto, lucroLiquido, imposto); 
	                	    	
	                        	EmpresaDAO ed = new EmpresaDAO();
	    						ed.create(e);
	    					} catch (SQLIntegrityConstraintViolationException e) {
	    				
	    						System.out.println("\n*** Esse CNPJ já foi cadastrado!");
	    						continue;
	    					}
	    					System.out.println("\nEmpresa cadastrada com sucesso!");
	    				}
				else if (opcao == 2) {
					EmpresaDAO ed = new EmpresaDAO();
					ArrayList<Empresa> lista = ed.getAll();
					if (lista.size() == 0) {
						System.out.println("\nO cadastro está vazio.");
					} else {
						System.out.println("\nEmpresa cadastradas:");
						for (Empresa e: lista) {
							System.out.println(e);
						}
					}
				}
				else if (opcao==3) {           //Erro em nome
					System.out.print("Digite uma parte do nome da empresa: ");
					String parte = teclado.nextLine();
					EmpresaDAO ed = new EmpresaDAO();
					ArrayList<Empresa> lista = ed.findByNomeLike(parte);
					if (lista.size() == 0) {
						System.out.println("\nNenhum resultado.");
					} else {
						System.out.println("\nResultado da pesquisa:");
						for (Empresa e: lista) {
							System.out.println(e);
						}
					}
				}	
				else if (opcao==4) { // Erro na criaçao do funcionario
					try {
						  System.out.print("\nDigite o nome do funcionario: ");
	                        String nomeFuncionario = teclado.nextLine();
	                        System.out.print("Digite a empresa do funcionario: ");
	                        String idEmpresa = teclado.nextLine();
	                        System.out.print("Digite o CPF do funcionario: ");
	                        String cpf = teclado.nextLine();
	                        System.out.print("Digite o valor pago de imposto: ");
	                        String valorImposto = teclado.nextLine();
	                        System.out.print("Digite a data de nascimento (YYYY-MM-DD): ");
	                        String dataNasc = teclado.nextLine();
	                        System.out.print("Digite o cargo do funcionário: ");
	                        Double cargo = teclado.nextDouble();
	                        System.out.print("Digite o salario: ");
	                        Double salario = teclado.nextDouble();
	                        System.out.print("Digite o celular: ");
	                        Double celular = teclado.nextDouble();
	    	                System.out.print("Digite a data de admissao (YYYY-MM-DD): ");
	                        Double dataAdmissao = teclado.nextDouble();
	                  
	                        
	                        Funcionario f = new Funcionario(nomeFuncionario, cpf, valorImposto, dataNasc, cargo, salario, celular, dataAdmissao); 
	                	    	
	                        FuncionarioDAO fd = new Funcionario();
	    						fd.create(f);
	    					} catch (SQLIntegrityConstraintViolationException e) {
	    				
	    						System.out.println("\n*** Esse CPF já foi cadastrado!");
	    						continue;
	    					}
	    					System.out.println("\nFuncionario cadastrado com sucesso!");
	    				}
				else if (opcao==5) {
					
				}	
				else if (opcao==6) {
					
				}
				else if (opcao==7) {
					
				}
				else if (opcao==8) {
					
				}	
				else if (opcao==9) {
					
				}	
				else if (opcao==10) {
					EmpresaDAO pd = new EmpresaDAO();
					ArrayList<Empresa> lista = pd.getAll();
					if (lista.size() == 0) {
						System.out.println("\nO cadastro está vazio.");
					} else {
						int i = 0;
						System.out.println("\nEmpresas cadastradas:");
						for (Empresa e: lista) {
							System.out.printf("[%d] %s\n", i++, e);
						}
						System.out.print("Qual pessoa deseja remover? ");
						int j = teclado.nextInt();
						teclado.nextLine();
						Empresa e = lista.get(j);
						pd.delete(e);
						System.out.println("\nCadastro atualizado com sucesso!");
					}
				}
				
				else if (opcao == 11) {
					break;
				}
				else {
					System.out.println("Opção inválida!");
				}
			}
			teclado.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			System.out.println("\nTenha um bom dia!");
		}
	}

}