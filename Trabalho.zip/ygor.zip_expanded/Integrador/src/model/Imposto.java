package model;

public class Imposto {
	private Double idEmpresa;
    private int ano;
    private Double valor;
    private String dataDeclaracao;

    public Imposto (Double idEmpresa,int ano, Double valor , String dataDeclaracao) {
        this.idEmpresa = idEmpresa;
    	this.ano = ano;
    	this.valor = valor;
        this.dataDeclaracao = dataDeclaracao;

    }
	public Double getidEmpresa() {
        return idEmpresa;
    }

    public void setidEmpresa(Double idEmpresa) {
		this.idEmpresa = idEmpresa;
    }
    
     public int getAno() {
        return this.ano;

    }
     public void setAno(int ano) {
         this.ano = ano;
     }
     
     public Double getValor() {
        return this.valor;
     
    }
     public void setValor(Double valor) {
         this.valor = valor;
     }
     
     public String getDataDeclaracao() {
        return this.dataDeclaracao;

    }
    public void setDataDeclaracao(String dataDeclaracao) {
         this.dataDeclaracao = dataDeclaracao;
     }
     
}