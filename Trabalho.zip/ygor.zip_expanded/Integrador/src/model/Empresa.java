package model;

public class Empresa {        
	    private String nomeEmpresa;    
	    private String cnpj;          
	    private String lugar;         
	    private String dataCriacao; 
	    private Double qtdeFuncionario; 
	    private Double lucroBruto;    
	    private Double lucroLiquido;   

	    
	    public Empresa(String nomeEmpresa, String cnpj, String lugar, String dataCriacao, Double qtdeFuncionario, Double lucroBruto, Double lucroLiquido) {
	    	
	        this.nomeEmpresa = nomeEmpresa;
	        this.cnpj = cnpj;
	        this.lugar = lugar;
	        this.dataCriacao = dataCriacao;
	        this.qtdeFuncionario = qtdeFuncionario;
	        this.lucroBruto = lucroBruto;
	        this.lucroLiquido = lucroLiquido;

	    }


		public String getNomeEmpresa() {
	        return nomeEmpresa;
	    }

	    public void setNomeEmpresa(String nomeEmpresa) {
	        this.nomeEmpresa = nomeEmpresa;
	    }

	    public String getCnpj() {
	        return cnpj;
	    }

	    public void setCnpj(String cnpj) {idEmpresa
	        this.cnpj = cnpj;
	    }

	    public String getLugar() {
	        return lugar;
	    }

	    public void setLugar(String lugar) {
	        this.lugar = lugar;
	    }

	    public String getDataCriacao() {
	        return dataCriacao;
	    }
	    
	    public void setDataCriacao(String dataCriacao) {
	        this.dataCriacao = dataCriacao;
	    }

	    public Double getQtdeFuncionario() {
	        return qtdeFuncionario;
	    }

	    public void setQtdeFuncionario(Double qtdeFuncionario) {
	        this.qtdeFuncionario = qtdeFuncionario;
	    }
	    
	    public Double getLucroBruto() {
	        return lucroBruto;
	    }

	    public void setLucroBruto(Double lucroBruto) {
	        this.lucroBruto = lucroBruto;
	    }

	    public Double getLucroLiquido() {
	        return lucroLiquido;
	    }

	    public void setLucroLiquido(Double lucroLiquido) {
	        this.lucroLiquido = lucroLiquido;
	    }
  

	    public String toString() {
	        return "Empresa ( " +
	                "Nome da Empresa = '" + nomeEmpresa + '\'' +
	                ", CNPJ = '" + cnpj + '\'' +
	                ", Lugar = '" + lugar + '\'' +
	                ", Data da Criação = '" + dataCriacao + '\'' +
	                ", Funcionarios = " + qtdeFuncionario +	            
	                ", Lucro Bruto = " + lucroBruto +              
	                ", Lucro Liquido = " + lucroLiquido +	                
	                ')';
	    }

	 
}
