package model;

public class Funcionario {
	private Double idEmpresa;
    private String nomeFuncionario;
    private String cpf;
    private Double salario;
    private String cargo;
    private String celular;
    private String dataNasc;
    private String dataAdmissao;


 

	public Funcionario(Double idEmpresa,String nomeFuncionario, String cpf, Double salario, String cargo,String celular, String dataNasc,String dataAdmissao) {
			this.idEmpresa = idEmpresa;
			this.nomeFuncionario = nomeFuncionario;
	        this.cpf = cpf;
	        this.salario = salario;
	        this.cargo = cargo;
	        this.celular = celular;
	        this.dataNasc = dataNasc;
	        this.dataAdmissao = dataAdmissao;

	}
	public Double getidEmpresa() {
        return idEmpresa;
    }

    public void setidEmpresa(Double idEmpresa) {
		this.idEmpresa = idEmpresa;
    }

	public String getNomeFuncionario() {
        return nomeFuncionario;
    }

    public void setNomeFuncionario(String nomeFuncionario) {
        this.nomeFuncionario = nomeFuncionario;
    }
    
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getDataNasc() {
       return dataNasc;
    }
    
    public void setDataNasc(String dataNasc) {
        this.dataNasc = dataNasc;
    }
    
    public String getCargo() {
        return cargo;
    }
    
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    public double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getDataAdmissao() {
        return dataAdmissao;
    }
    
    public void setDataAdmissao(String dataAdmissao) {
        this.dataAdmissao = dataAdmissao;
    }
    
    public String toString() {
        return "Funcionario (" +
                "funcionario = '" + nomeFuncionario + '\'' +
                ", cpf = '" + cpf + '\'' +
                ", data de nascimento = " + dataNasc +
                ", cargo = '" + cargo + '\'' +
                ", salario = " + salario +
                ", celular = '" + celular + '\'' +
                ", data de admissao = " + dataAdmissao +
                ')';
    }

}