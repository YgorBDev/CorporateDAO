package persistencia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;

import java.util.ArrayList;


import model.Imposto;


public class ImpostoDAO {

    private Connection bd;


    public ImpostoDAO() {

        this.bd = BancosDeDados.getBd();

    }


    public void create(Imposto i) throws SQLException {

        String query = "INSERT INTO funcionario VALUES (null,?, ?, ?, ?)";

        try (PreparedStatement st = this.bd.prepareStatement(query)) {

        	st.setDouble(1, i.getidEmpresa());
        	st.setDouble(2, i.getValor());
        	st.setInt(3, i.getAno());
            st.setString(4, i.getDataDeclaracao());

            

            st.executeUpdate();

        }

    }


    public ArrayList<Imposto> getAll() throws SQLException {

        ArrayList<Imposto> lista = new ArrayList<Imposto>();

        String query = "SELECT * FROM imposto"; 

        try (PreparedStatement st = this.bd.prepareStatement(query);

             ResultSet res = st.executeQuery()) {

            while (res.next()) { 
            	
            	Double idEmpresa = res.getDouble("idEmpresa");
            	int ano = res.getInt("ano");

            	Double valor = res.getDouble("valor");

            	String dataDeclaracao = res.getString("dataDeclaracao");

            	 	

                	Imposto i = new Imposto(idEmpresa,ano, valor, dataDeclaracao);

                	lista.add(i);

            }

        }

        return lista;

    }


    public void update(Imposto i) throws SQLException {

        String query = "UPDATE imposto SET ano = ?, valor = ?, dataDeclaracao = ? WHERE idEmpresa= ?";

        try (PreparedStatement st = this.bd.prepareStatement(query)) {

        	
            st.setInt(1, i.getAno());

            st.setDouble(2, i.getValor());

            st.setString(3, i.getDataDeclaracao());

           st.setDouble(4, i.getidEmpresa());

            st.executeUpdate();

        }

    }


    public void delete(Imposto i) throws SQLException {

        String query = "DELETE FROM imposto WHERE idEmpresa = ?";

        try (PreparedStatement st = this.bd.prepareStatement(query)) {

            st.setDouble(1, i.getidEmpresa());

            st.executeUpdate();

        }

    }


    public ArrayList<Imposto> findByNomeLike(Double s) throws SQLException {

        ArrayList<Imposto> lista = new ArrayList<>();

        String query = "SELECT * FROM imposto WHERE idEmpresa = ?";

        try (PreparedStatement st = this.bd.prepareStatement(query)) {

            st.setDouble(1, s);

            try (ResultSet res = st.executeQuery()) {

                while (res.next()) {
                	Double idEmpresa = res.getDouble("idEmpresa");
                	int ano = res.getInt("ano");

                	Double valor = res.getDouble("valor");

                	String dataDeclaracao = res.getString("dataDeclaracao");

                	 	

                    	Imposto i = new Imposto(idEmpresa,ano, valor, dataDeclaracao);

                    lista.add(i);

                }

            }

        }

        return lista;

    }

}