package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Empresa;

public class EmpresaDAO {
	private Connection bd;
	
	public EmpresaDAO() {
		this.bd = BancosDeDados.getBd();
	}
	
	public void create(Empresa e) throws SQLException {
		String query = "INSERT INTO empresa VALUES(null, ?, ?, ?)";
		PreparedStatement st = this.bd.prepareStatement(query);
		st.setString(1, e.getNome());
		st.setString(2, e.getCpf());
		st.setString(3, e.getDataNascimento());
		st.executeUpdate();
	}
	
	public ArrayList<Empresa> getAll() throws SQLException {
		ArrayList<Empresa> lista = new ArrayList<Empresa>();
		String query = "SELECT nome, cpf, data_nasc FROM pessoa";
		PreparedStatement st = this.bd.prepareStatement(query);
		ResultSet res = st.executeQuery();
		while (res.next()) {
			String nomeEmpresa = res.getString("nome");
			String cpf = res.getString("cpf");
			String dataNasc = res.getString("data_nasc");
			Empresa e = new Empresa(nomeEmpresa, cpf, dataNasc);
			lista.add(e);
		}
		return lista;
	}
	
	public void update(Empresa e) throws SQLException {
		String query = """
				UPDATE Empresa
				SET nome = ?, data_nasc = ?
				WHERE cpf = ?
		""";
		PreparedStatement st = this.bd.prepareStatement(query);
		st.setString(1, e.getNome());
		st.setString(2, e.getDataNascimento());
		st.setString(3, e.getCpf());
		st.executeUpdate();
	}
	
	public void delete(Empresa e) throws SQLException {
		String query = """
				DELETE FROM Empresa
				WHERE cpf = ?
		""";
		PreparedStatement st = this.bd.prepareStatement(query);
		st.setString(1, e.getCpf());
		st.executeUpdate();
	}
	
	public ArrayList<Empresa> findByNomeLike(String s) throws SQLException {
		ArrayList<Empresa> lista = new ArrayList<Empresa>();
		String query = """
				SELECT nome, cpf, data_nasc
				FROM Empresa
				WHERE nome LIKE ?
		""";
		PreparedStatement st = this.bd.prepareStatement(query);
		st.setString(1, "%" + s + "%");
		ResultSet res = st.executeQuery();
		while (res.next()) {
			String nomeEmpresa = res.getString("nome");
			String cpf = res.getString("cpf");
			String dataNasc = res.getString("data_nasc");
			Empresa e = new Empresa(nomeEmpresa, cpf, dataNasc);
			lista.add(e);
		}
		return lista;
	}
}