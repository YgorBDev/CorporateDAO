package apresentacao;

import java.util.ArrayList;
import java.util.Scanner;
import model.Empresa;
import persistencia.EmpresaDAO;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

 
public class Main {
	public static void main(String[] args) {  

		try {
			Scanner teclado = new Scanner(System.in);

			while (true) {
				System.out.println("\n== Sistema Empresarial ==");
				System.out.println("1) Cadastrar uma empresa");
				System.out.println("2) Mostrar as empresas cadastradas");
				System.out.println("3) Buscar empresa");
				System.out.println("4) Cadastrar um funcionario");
				System.out.println("5) Mostrar os funcionario cadastradas");
				System.out.println("3) Buscar funcionario");	
				System.out.println("7) Declarar imposto empresa");
				System.out.println("8) Mostar declaraçoes imposto");
				System.out.println("9) Excluir funcionario");
				System.out.println("10) Excluir empresa");
				System.out.println("11) Encerrar");
				
				System.out.print("Escolha uma opção: ");
				int opcao = teclado.nextInt();
				teclado.nextLine();

				if (opcao == 1) {
					try {
						  System.out.print("\nDigite o nome da empresa: ");
	                        String nomeEmpresa = teclado.nextLine();
	                        System.out.print("Digite o CNPJ da empresa: ");
	                        String cnpj = teclado.nextLine();
	                        System.out.print("Digite o lugar: ");
	                        String lugar = teclado.nextLine();
	                        System.out.print("Digite a data de criação (YYYY-MM-DD): ");
	                        String dataCriacao = teclado.nextLine();
	                        System.out.print("Digite o lucro bruto: ");
	                        Double lucroBruto = teclado.nextDouble();
	                        System.out.print("Digite o lucro liquido: ");
	                        Double lucroLiquido = teclado.nextDouble();
	    	                System.out.print("Digite o imposto: ");
	                        Double imposto = teclado.nextDouble();
	                        System.out.print("Digite a quantidade de funcionários: ");
	                        Double qtdeFuncionario = teclado.nextDouble();
	                        
	                        Empresa e = new Empresa(nomeEmpresa, cnpj, lugar, dataCriacao, lucroBruto, lucroLiquido, imposto, qtdeFuncionario); 
	                	    	
	                        	EmpresaDAO ed = new EmpresaDAO();
	    						ed.create(e);
	    					} catch (SQLIntegrityConstraintViolationException e) {
	    				
	    						System.out.println("\n*** Esse CNPJ já foi cadastrado!");
	    						continue;
	    					}
	    					System.out.println("\nEmpresa cadastrada com sucesso!");
	    				}
				else if (opcao == 2) {
					EmpresaDAO ed = new EmpresaDAO();
					ArrayList<Empresa> lista = ed.getAll();
					if (lista.size() == 0) {
						System.out.println("\nO cadastro está vazio.");
					} else {
						System.out.println("\nEmpresa cadastradas:");
						for (Empresa e: lista) {
							System.out.println(e);
						}
					}
				}
				
				else if (opcao == 11) {
					break;
				}
				else {
					System.out.println("Opção inválida!");
				}
			}
			teclado.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			System.out.println("\nTenha um bom dia!");
		}
	}

}