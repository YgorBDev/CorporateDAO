package model;

public class Status {

}
