CREATE DATABASE primeiro_bd_2k_2024;

DROP DATABASE primeiro_bd_2k_2024;

USE primeiro_bd_2k_2024;

CREATE TABLE usuario(
	id BIGINT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(20) NOT NULL,
    PRIMARY KEY(id)
);

CREATE TABLE veiculo(
	id BIGINT NOT NULL UNIQUE AUTO_INCREMENT,
    marca VARCHAR(40) NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    cor VARCHAR(25),
    id_usuario BIGINT,
    PRIMARY KEY(id),
    FOREIGN KEY(id_usuario) REFERENCES usuario(id)
);